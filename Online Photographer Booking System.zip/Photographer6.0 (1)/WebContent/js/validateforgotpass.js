			  function sendEmail() {
				  	  	console.log(document.getElementById("email1").value);
					    console.log("Captcha: ".concat(document.getElementById("pin").value));
					    if(document.getElementById("email1").value==null)
					    	{
					    	alert("mail sent successfully");
					    	 location.href="ChangePassword.jsp";
					    	}else{
					             Email.send({ 
						          Host: "smtp.gmail.com", 
						          Username: "InfophotographerAS@gmail.com", 
						          Password: "Photo@123", 
						          To: document.getElementById("email1").value,
						          From: "InfophotographerAS@gmail.com", 
						          Subject: "Reset your password by verifying security code", 
						          Body: "Captcha: ".concat(document.getElementById("pin").value),
							          
						        }) //send()
						        alert("mail sent successfully");
					             location.href="ForgotPassword.jsp";
					    	}//else
    				}//sndEmail()
    

      
        